"wawotest" <-
function(x, ...)
  {
    UseMethod("wawotest")    
  }

