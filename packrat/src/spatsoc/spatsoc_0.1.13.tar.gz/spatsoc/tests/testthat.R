library(testthat)
library(spatsoc)

test_check("spatsoc")
